//
//  CustomTableViewCell.swift
//  MusicPlayerDemo
//
//  Created by Sumit Jain on 06/09/23.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
  @IBOutlet weak var name: UILabel!
  @IBOutlet weak var artist: UILabel!
  @IBOutlet weak var duration: UILabel!
  override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

  func setData(mediadata: MediaDataModel) {
    name.text = mediadata.title
    artist.text = mediadata.artist
    if let durationvalue = mediadata.duration {
      duration.text = "\(durationvalue)"
    }
  }

}
