//
//  MediaViewModel.swift
//  MusicPlayerDemo
//
//  Created by Sumit Jain on 07/09/23.
//

import Foundation

class MediaViewModel {
  private var mediaService: MediaServiceProtocol

  init(mediaService: MediaServiceProtocol) {
    self.mediaService = mediaService
  }

  func fetchMediaList(completion: @escaping([MediaDataModel]) -> ()) {
    mediaService.getMediaList { data, error in

      if let error = error {
       // completion(nil, error)
      }
      if let data = data {
        completion(data)
      }
    }
  }

}
