//
//  ViewController.swift
//  MusicPlayerDemo
//
//  Created by Sumit Jain on 06/09/23.
//

import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var tableView: UITableView!
  private var medialist = [MediaDataModel]()

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    let mediaService = MediaService()
    let MediaViewModel = MediaViewModel(mediaService: mediaService)

    MediaViewModel.fetchMediaList { [weak self] data in
      self?.medialist = data
      DispatchQueue.main.async {
        self?.tableView.reloadData()
      }
    }
//    mediaService.getMediaList { [weak self] data, error in
//
//      if let error = error {
//        // Show erro
//      }
//      if let data = data {
//        medialist = data
//
//        DispatchQueue.main.async {
//          self?.tableView.reloadData()
//        }
//      }
//    }
  }

}


extension ViewController: UITableViewDataSource {

  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    medialist.count
  }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell") as! CustomTableViewCell
    let media = medialist[indexPath.row]
    cell.setData(mediadata: media)
    return cell
  }
}


extension ViewController: UITableViewDelegate {
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let media = medialist[indexPath.row]
    let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
    if let url = media.album, let playerViewController = mainStoryboard.instantiateViewController(withIdentifier: "PlayerViewController") as? PlayerViewController {
      playerViewController.playerUrl = url
              self.present(playerViewController, animated: true, completion: nil)
          }

    }
  }
