//
//  MediaDataModel.swift
//  MusicPlayerDemo
//
//  Created by Sumit Jain on 06/09/23.
//

import Foundation

struct MediaDataModel: Codable {
  let title: String?
  let artist: String?
  let album: String?
  let duration: Double?
}
