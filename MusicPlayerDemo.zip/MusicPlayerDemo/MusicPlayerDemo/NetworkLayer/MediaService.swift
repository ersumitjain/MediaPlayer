//
//  MediaService.swift
//  MusicPlayerDemo
//
//  Created by Sumit Jain on 06/09/23.
//

import Foundation


protocol MediaServiceProtocol {
  func getMediaList(completion: ([MediaDataModel]?, Error?) -> ())
}

class MediaService: MediaServiceProtocol {
  func getMediaList(completion: ([MediaDataModel]?, Error?) -> ()) {
    let media1 = MediaDataModel(title: "Media1", artist: "artist1", album: "http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Kangaroo_MusiQue_-_The_Neverwritten_Role_Playing_Game.mp3", duration: 40.0)
    let media2 = MediaDataModel(title: "Media2", artist: "artist2", album: "http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Sevish_-__nbsp_.mp3", duration: 20.0)
    completion([media1, media2], nil)
  }

}
