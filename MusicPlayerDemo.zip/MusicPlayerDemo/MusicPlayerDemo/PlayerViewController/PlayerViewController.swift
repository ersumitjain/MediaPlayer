//
//  PlayerViewController.swift
//  MusicPlayerDemo
//
//  Created by Sumit Jain on 06/09/23.
//

import UIKit
import AVFoundation
import AVKit

class PlayerViewController: UIViewController {

  @IBOutlet weak var playerView: UIView!
  @IBOutlet weak var volumeValue: UISlider!
  @IBOutlet weak var mediaValue: UISlider!

  var playerUrl = ""

  private var player: AVPlayer?


  override func viewDidLoad() {
    super.viewDidLoad()

    // Do any additional setup after loading the view.
    if let url = URL(string: playerUrl) {
      player = AVPlayer(url: url)
      let playerLayer = AVPlayerLayer(player: player)
      playerLayer.frame = self.playerView.bounds
      self.playerView.layer.addSublayer(playerLayer)

      player?.volume = 0.2
      player?.play()
    }

  }

  @IBAction func play(_ sender: Any) {
    player?.play()
  }

  @IBAction func pause(_ sender: Any) {
    player?.pause()
  }

  @IBAction func volumeControl(_ sender: Any) {
    player?.volume = volumeValue.value
  }

  @IBAction func mediaControl(_ sender: Any) {
   // player.see
  }
}
