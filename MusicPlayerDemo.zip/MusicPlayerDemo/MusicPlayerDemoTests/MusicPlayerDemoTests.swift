//
//  MusicPlayerDemoTests.swift
//  MusicPlayerDemoTests
//
//  Created by Sumit Jain on 06/09/23.
//

import XCTest
@testable import MusicPlayerDemo

final class MusicPlayerDemoTests: XCTestCase {

//  var mockSerice: MockService
//  var viewModel: MediaViewModel
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

  func testFetchRequest() {

  }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}

class MockService: MediaServiceProtocol {
  func getMediaList(completion: ([MediaDataModel]?, Error?) -> ()) {
    let media1 = MediaDataModel(title: "Media1", artist: "artist1", album: "http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Kangaroo_MusiQue_-_The_Neverwritten_Role_Playing_Game.mp3", duration: 40.0)
    let media2 = MediaDataModel(title: "Media2", artist: "artist2", album: "http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Sevish_-__nbsp_.mp3", duration: 20.0)
    completion([media1, media2], nil)
  }
}
